
module.exports = [
    {short:"  " , name:"Please select a city"},
    {short:"AF" , name:"Afghanistan"},
    {short:"AL" , name:"Albania"},
    {short:"DZ" , name:"Algeria"}
]